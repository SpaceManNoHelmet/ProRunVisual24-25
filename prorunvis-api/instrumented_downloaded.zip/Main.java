public class Main {

    public static void main(String[] args) {
        prorunvis.Trace.next_elem(0);
        methodOne();
    }

    public static void methodOne() {
        prorunvis.Trace.next_elem(1);
        System.out.println("Inside methodOne");
        methodTwo();
    }

    public static void methodTwo() {
        prorunvis.Trace.next_elem(2);
        System.out.println("Inside methodTwo");
        methodThree();
    }

    public static void methodThree() {
        prorunvis.Trace.next_elem(3);
        System.out.println("Inside methodThree");
    }
}
